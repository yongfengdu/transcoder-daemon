gcc cttmetrics_sample.cpp -m64 -I../include -L../_bin -lcttmetrics -lstdc++ -o metrics_monitor
