export LD_LIBRARY_PATH=$PWD/../_bin:$LD_LIBRARY_PATH

./metrics_monitor
